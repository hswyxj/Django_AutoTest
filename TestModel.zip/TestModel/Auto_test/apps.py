# Auto_test/apps.py

from suit.apps import DjangoSuitConfig
from suit.menu import ParentItem, ChildItem


class SuitConfig(DjangoSuitConfig):
    ##layout这个参数决定你的网页是初始样式是垂直样式还是水平样式，可选参数为‘horizontal’或‘vertical’
    layout = 'vertical'

    #
    menu = (
        ParentItem('自动化管理', children=[
            ChildItem(model='TestModel.Column'),
            ChildItem(model='TestModel.Article'),
            ChildItem(model='TestModel.Testpage'),
            ChildItem(model='TestModel.Testcase'),
            ChildItem('APP自动化测试管理', url='/admin/Auto_test/column/'),
            #ChildItem('页面管理', url='/admin/TestModel/testpage/'),
            #ChildItem('用例管理', url='/admin/TestModel/testcase/'),
        ], icon='fa fa-leaf'),

        ParentItem('Integrations', children=[
            ChildItem(model='TestModel.city'),
        ]),

        ParentItem('用户管理', children=[
            ChildItem(model='auth.user'),
            ChildItem('组别', 'auth.group'),
        ], icon='fa fa-users'),

        ParentItem('个人中心', children=[
            ChildItem('修改密码', url='admin:password_change'),
            #ChildItem('测试打开google', url='http://google.com', target_blank=True),
        ], align_right=True, icon='fa fa-cog'),
    )



    def ready(self):
        super(SuitConfig, self).ready()


    def prevent_user_last_login(self):
        """
        Disconnect last login signal
        """
        from django.contrib.auth import user_logged_in
        from django.contrib.auth.models import update_last_login
        user_logged_in.disconnect(update_last_login)